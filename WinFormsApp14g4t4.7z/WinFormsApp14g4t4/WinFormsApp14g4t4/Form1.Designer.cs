﻿namespace WinFormsApp14g4t4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEnemyHP = new System.Windows.Forms.TextBox();
            this.enemy = new System.Windows.Forms.Label();
            this.txtEnemyName = new System.Windows.Forms.TextBox();
            this.playerMPLabel = new System.Windows.Forms.Label();
            this.txtPlayerMPBox = new System.Windows.Forms.TextBox();
            this.playerHPLabel = new System.Windows.Forms.Label();
            this.txtPlayerHPBox = new System.Windows.Forms.TextBox();
            this.txtplayerName = new System.Windows.Forms.TextBox();
            this.playerlabel = new System.Windows.Forms.Label();
            this.btnDef = new System.Windows.Forms.Button();
            this.btnMagic = new System.Windows.Forms.Button();
            this.btnAttack = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(300, 188);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(96, 64);
            this.btnStart.TabIndex = 30;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(300, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 15);
            this.label1.TabIndex = 29;
            this.label1.Text = "enemyHP";
            // 
            // txtEnemyHP
            // 
            this.txtEnemyHP.Location = new System.Drawing.Point(300, 97);
            this.txtEnemyHP.Name = "txtEnemyHP";
            this.txtEnemyHP.Size = new System.Drawing.Size(100, 23);
            this.txtEnemyHP.TabIndex = 28;
            // 
            // enemy
            // 
            this.enemy.AutoSize = true;
            this.enemy.Location = new System.Drawing.Point(300, 26);
            this.enemy.Name = "enemy";
            this.enemy.Size = new System.Drawing.Size(76, 15);
            this.enemy.TabIndex = 27;
            this.enemy.Text = "enemy name";
            // 
            // txtEnemyName
            // 
            this.txtEnemyName.Location = new System.Drawing.Point(300, 44);
            this.txtEnemyName.Name = "txtEnemyName";
            this.txtEnemyName.Size = new System.Drawing.Size(100, 23);
            this.txtEnemyName.TabIndex = 26;
            // 
            // playerMPLabel
            // 
            this.playerMPLabel.AutoSize = true;
            this.playerMPLabel.Location = new System.Drawing.Point(33, 105);
            this.playerMPLabel.Name = "playerMPLabel";
            this.playerMPLabel.Size = new System.Drawing.Size(25, 15);
            this.playerMPLabel.TabIndex = 25;
            this.playerMPLabel.Text = "MP";
            // 
            // txtPlayerMPBox
            // 
            this.txtPlayerMPBox.Location = new System.Drawing.Point(33, 123);
            this.txtPlayerMPBox.Name = "txtPlayerMPBox";
            this.txtPlayerMPBox.Size = new System.Drawing.Size(100, 23);
            this.txtPlayerMPBox.TabIndex = 24;
            // 
            // playerHPLabel
            // 
            this.playerHPLabel.AutoSize = true;
            this.playerHPLabel.Location = new System.Drawing.Point(33, 59);
            this.playerHPLabel.Name = "playerHPLabel";
            this.playerHPLabel.Size = new System.Drawing.Size(23, 15);
            this.playerHPLabel.TabIndex = 23;
            this.playerHPLabel.Text = "HP";
            // 
            // txtPlayerHPBox
            // 
            this.txtPlayerHPBox.Location = new System.Drawing.Point(33, 77);
            this.txtPlayerHPBox.Name = "txtPlayerHPBox";
            this.txtPlayerHPBox.Size = new System.Drawing.Size(100, 23);
            this.txtPlayerHPBox.TabIndex = 22;
            // 
            // txtplayerName
            // 
            this.txtplayerName.Location = new System.Drawing.Point(33, 27);
            this.txtplayerName.Name = "txtplayerName";
            this.txtplayerName.Size = new System.Drawing.Size(100, 23);
            this.txtplayerName.TabIndex = 21;
            // 
            // playerlabel
            // 
            this.playerlabel.AutoSize = true;
            this.playerlabel.Location = new System.Drawing.Point(33, 9);
            this.playerlabel.Name = "playerlabel";
            this.playerlabel.Size = new System.Drawing.Size(39, 15);
            this.playerlabel.TabIndex = 20;
            this.playerlabel.Text = "player";
            // 
            // btnDef
            // 
            this.btnDef.Location = new System.Drawing.Point(163, 147);
            this.btnDef.Name = "btnDef";
            this.btnDef.Size = new System.Drawing.Size(88, 54);
            this.btnDef.TabIndex = 19;
            this.btnDef.Text = "Def";
            this.btnDef.UseVisualStyleBackColor = true;
            // 
            // btnMagic
            // 
            this.btnMagic.Location = new System.Drawing.Point(163, 87);
            this.btnMagic.Name = "btnMagic";
            this.btnMagic.Size = new System.Drawing.Size(88, 54);
            this.btnMagic.TabIndex = 18;
            this.btnMagic.Text = "Magic";
            this.btnMagic.UseVisualStyleBackColor = true;
            this.btnMagic.Click += new System.EventHandler(this.btnMagic_Click);
            // 
            // btnAttack
            // 
            this.btnAttack.Location = new System.Drawing.Point(163, 27);
            this.btnAttack.Name = "btnAttack";
            this.btnAttack.Size = new System.Drawing.Size(88, 54);
            this.btnAttack.TabIndex = 17;
            this.btnAttack.Text = "Attack";
            this.btnAttack.UseVisualStyleBackColor = true;
            this.btnAttack.Click += new System.EventHandler(this.btnAttack_Click_1);
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(8, 277);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(408, 137);
            this.txtOutput.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 450);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtEnemyHP);
            this.Controls.Add(this.enemy);
            this.Controls.Add(this.txtEnemyName);
            this.Controls.Add(this.playerMPLabel);
            this.Controls.Add(this.txtPlayerMPBox);
            this.Controls.Add(this.playerHPLabel);
            this.Controls.Add(this.txtPlayerHPBox);
            this.Controls.Add(this.txtplayerName);
            this.Controls.Add(this.playerlabel);
            this.Controls.Add(this.btnDef);
            this.Controls.Add(this.btnMagic);
            this.Controls.Add(this.btnAttack);
            this.Controls.Add(this.txtOutput);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEnemyHP;
        private System.Windows.Forms.Label enemy;
        private System.Windows.Forms.TextBox txtEnemyName;
        private System.Windows.Forms.Label playerMPLabel;
        private System.Windows.Forms.TextBox txtPlayerMPBox;
        private System.Windows.Forms.Label playerHPLabel;
        private System.Windows.Forms.TextBox txtPlayerHPBox;
        private System.Windows.Forms.TextBox txtplayerName;
        private System.Windows.Forms.Label playerlabel;
        private System.Windows.Forms.Button btnDef;
        private System.Windows.Forms.Button btnMagic;
        private System.Windows.Forms.Button btnAttack;
        private System.Windows.Forms.TextBox txtOutput;
    }
}
