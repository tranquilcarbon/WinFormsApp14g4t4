﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp14g4t4
{
    public class Rooms
    {
        private int _terrainID;
        private string _Name;


        public int terrainID
        {
            get { return _terrainID; }
            set { _terrainID = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public Rooms(string Name, int terrainID)
        {
            this.Name = Name;
            this.terrainID = terrainID;
        }



    }
}
