﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp14g4t4
{
    internal class Fight
    {
        Player _player;
        Enemy _enemy;
        Rooms _rooms;

        public Player Player
        {
            get { return _player; }
            set { _player = value; }
        }
        public Enemy Enemy
        {
            get { return _enemy; }
            set { _enemy = value; }
        }
        public Rooms Rooms
        {
            get { return _rooms; }
            set { _rooms = value; }
        }

        public void startFight(Player player, Enemy enemy, Rooms rooms, TextBox txtoutput, TextBox txtEnemyName, TextBox txtEnemyHP)
        {
            this.Player = player;
            this.Enemy = enemy;
            this.Rooms = rooms;

            //reset player hp
            this.Player.curHP = this.Player.statHP;
            this.Enemy.curHP = this.Player.StatMP;
            txtEnemyName.Text = this.Enemy.Name;
            txtEnemyHP.Text = this.Enemy.curHP.ToString();

            txtoutput.AppendText("fight started against " + this.Enemy.Name + " in room " + this.Rooms.Name + Environment.NewLine);
            txtoutput.AppendText("player is first." + Environment.NewLine);
        }

        public void checkHP(TextBox txtOutPrint)
        {
            if (this.Player.curHP <= 0)
            {
                txtOutPrint.AppendText("You died. game over." + Environment.NewLine);
            }else if (this.Enemy.curHP <=0 )
            {
                txtOutPrint.AppendText("enemy has died." + Environment.NewLine);
                this.Enemy.speakDeath(txtOutPrint);
            }
        }
    }
}
