﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp14g4t4
{
    public partial class Form1 : Form
    {
        bool chosenclass = true;
        Player Player = new Player();

        //Classes
        Classes warrior = new Classes("Warrior", 40, 10, 15);
        Classes mage = new Classes("Mage", 25, 45, 5);

        //Rooms
        Rooms training = new Rooms("Training Room", 0);

        //Enemies
        Enemy human = new Enemy("Human", 10, 10, "I'm Dead");

        public Form1()
        {
            InitializeComponent();
            txtOutput.AppendText("Choose your class using the buttons!" + Environment.NewLine);
            txtOutput.AppendText("Attack: Warrior" + Environment.NewLine);
            txtOutput.AppendText("Magic: Mage" + Environment.NewLine);
        }

        private void Form1_Load(object sender, EventArgs e)
        {




        }


        private void btnAttack_Click_1(object sender, EventArgs e)
        {
            if (chosenclass == false)
            {
                fight.Player.Attack(fight.Player, fight.Enemy, txtOutput, txtEnemyHP);
                fight.checkHP(txtOutput);
            }
            else
            {
                Player.updatestats(warrior, txtplayerName, txtPlayerHPBox, txtPlayerMPBox);
                txtOutput.AppendText("game can now be started. please click on start button.");
                chosenclass = false;
            }
        }

        private void btnMagic_Click(object sender, EventArgs e)
        {
            if (chosenclass == false)
            {
                //will be magic in future
            }
            else
            {
                Player.updatestats(mage, txtplayerName, txtPlayerHPBox, txtPlayerMPBox);
                txtOutput.AppendText("game can now be started. please click on start button.");
                chosenclass = false;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            RandomEnemy = 0;

            if (RandomEnemy == 0)
                _
                    fight.startFight(Player, human, training, txtOutput, txtEnemyName, txtEnemyHP);
        }
    }
}
