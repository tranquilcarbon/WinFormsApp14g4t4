﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp14g4t4
{
    public class Player : Character
    {
        private int _statMP;
        int _curMP;
        Classes Classes;
        public int StatMP
        {
            get { return _statMP; }
            set { _statMP = value; }
        }
        public Classes classes
        {
            get { return Classes; }
            set { Classes = value; }
        }
        public int curMP
        {
            set { _curMP = value; }
            get { return _curMP; }
        }
        public void updatestats(Classes Classes, TextBox txtplayername, TextBox txtPlayerHPBox, TextBox txtPlayerMPBox)
        {
            this.classes = Classes;
            this.Name = classes.Name;
            this.statHP = classes.baseHP;
            this.StatMP = classes.baseMP;
            this.StatAttack = classes.baseAttack;

            this.curHP = this.statHP;
            this.curMP = this.statHP;

            txtplayername.Text = this.Name;
            txtPlayerHPBox.Text = this.curHP.ToString();
            txtPlayerMPBox.Text = this.curMP.ToString();
        }
        public override void Attack(Character source, Character target, TextBox txtoutput, TextBox txtPlayerHPBox)
        {
            if (this.curHP > 0)
            {
                target.curHP = target.curHP - source.StatAttack;
                txtoutput.AppendText(source.Name + " attacked " + target.Name + Environment.NewLine);
                txtPlayerHPBox.Text = target.curHP.ToString();
                return;
            }
            else
            {
                txtoutput.AppendText(source.Name + " tried to attack but " + target.Name + " was already dead." + Environment.NewLine);
            }
        }
    }
}
