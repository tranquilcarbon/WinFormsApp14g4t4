﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp14g4t4
{
    public class Enemy : Character
    {
        string _deathText;

        public string deathText
        {
            get { return _deathText; }
            set { _deathText = value; }
        }

        public Enemy(string Name, int statHP, int statAttack, string deathText)
        {
            this.Name = Name;
            this.statHP = statHP;
            this.curHP = statHP;
            this.StatAttack = statAttack;
            this.deathText = deathText; 
        }

        public void speakDeath(TextBox txtOutput)
        {
            txtOutput.AppendText(this.Name + ": " + this.deathText + Environment.NewLine);
        }


    }
}
